import type { Address } from 'viem';

export const CONTRACTS: { [key: string]: Address } = {
  KINTSU: '0xe1d2439b75fb9746E7Bc6cB777Ae10AA7f7ef9c5' as Address, // sMON token
  MAGMA_STAKE: '0x2c9C959516e9AAEdB2C748224a41249202ca8BE7' as Address,
  GMON: '0xaEef2f6B429Cb59C9B2D7bB2141ADa993E8571c3' as Address,
  PANCAKESWAP: '0x94D220C58A23AE0c2eE29344b00A30D1c2d9F1bc' as Address, // Universal Router
  PERMIT2: '0xC51DA9473283695884AD536FFD180e618Bf6186e' as Address,
  WMON: '0x760AfE86e5de5fa0Ee542fc7B7B713e1c5425701' as Address,
};

// Alias for consistency
export const UNIVERSAL_ROUTER = CONTRACTS.PANCAKESWAP;
