interface Window {
  ethereum?: import('ethers').providers.ExternalProvider | any;
}
